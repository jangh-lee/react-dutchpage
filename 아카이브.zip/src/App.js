import './App.css';
import {ExpenseMain} from "./components/ExpenseMain";
import {AddMenbers} from "./components/AddMembers";
import {BrowserRouter,Route} from "react-router-dom";

const App = () => (
    <BrowserRouter>
      <Route>
        <Route path="/" component={<AddMenbers />} />
        <Route path="/expense" component={<ExpenseMain />} />
      </Route>
    </BrowserRouter>
)

export default App