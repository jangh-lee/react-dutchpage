export const ExpenseMain = () => {
    return (
        <div> ExpenseMain components
        <div>
            {/*TODO : ㅂㅣ용 추가 폼 컴포넌트 렌더링 */}
            {/*TODO : 정산결과 컴포넌트 렌더링 */}
        </div>
        <div>
            {/*TODO : 그룹명 헤드 렌더링 */}
            {/*TODO : 비용 리스트 컴포넌트 렌더링 */}
        </div>
        </div>
    )
}